/**
 */
package org.xtext.ecerule.ece;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mul Or Div</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.ecerule.ece.EcePackage#getMulOrDiv()
 * @model
 * @generated
 */
public interface MulOrDiv extends PlusOrMinus
{
} // MulOrDiv
