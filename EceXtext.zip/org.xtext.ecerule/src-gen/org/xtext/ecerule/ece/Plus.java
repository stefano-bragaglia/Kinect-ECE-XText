/**
 */
package org.xtext.ecerule.ece;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Plus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.ecerule.ece.EcePackage#getPlus()
 * @model
 * @generated
 */
public interface Plus extends PlusOrMinus
{
} // Plus
