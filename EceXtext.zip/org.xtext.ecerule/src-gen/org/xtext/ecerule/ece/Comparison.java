/**
 */
package org.xtext.ecerule.ece;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Comparison</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.ecerule.ece.EcePackage#getComparison()
 * @model
 * @generated
 */
public interface Comparison extends And
{
} // Comparison
