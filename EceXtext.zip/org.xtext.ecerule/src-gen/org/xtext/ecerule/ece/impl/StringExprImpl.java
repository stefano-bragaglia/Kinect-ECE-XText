/**
 */
package org.xtext.ecerule.ece.impl;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.ecerule.ece.EcePackage;
import org.xtext.ecerule.ece.StringExpr;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>String Expr</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.ecerule.ece.impl.StringExprImpl#getValueDirect <em>Value Direct</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class StringExprImpl extends EqualityImpl implements StringExpr
{
  /**
   * The default value of the '{@link #getValueDirect() <em>Value Direct</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValueDirect()
   * @generated
   * @ordered
   */
  protected static final String VALUE_DIRECT_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getValueDirect() <em>Value Direct</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValueDirect()
   * @generated
   * @ordered
   */
  protected String valueDirect = VALUE_DIRECT_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected StringExprImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return EcePackage.Literals.STRING_EXPR;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getValueDirect()
  {
    return valueDirect;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setValueDirect(String newValueDirect)
  {
    String oldValueDirect = valueDirect;
    valueDirect = newValueDirect;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, EcePackage.STRING_EXPR__VALUE_DIRECT, oldValueDirect, valueDirect));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case EcePackage.STRING_EXPR__VALUE_DIRECT:
        return getValueDirect();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case EcePackage.STRING_EXPR__VALUE_DIRECT:
        setValueDirect((String)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case EcePackage.STRING_EXPR__VALUE_DIRECT:
        setValueDirect(VALUE_DIRECT_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case EcePackage.STRING_EXPR__VALUE_DIRECT:
        return VALUE_DIRECT_EDEFAULT == null ? valueDirect != null : !VALUE_DIRECT_EDEFAULT.equals(valueDirect);
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (valueDirect: ");
    result.append(valueDirect);
    result.append(')');
    return result.toString();
  }

} //StringExprImpl
