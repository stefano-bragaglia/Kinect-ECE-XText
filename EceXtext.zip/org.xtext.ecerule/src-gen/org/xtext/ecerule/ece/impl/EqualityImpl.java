/**
 */
package org.xtext.ecerule.ece.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.xtext.ecerule.ece.EcePackage;
import org.xtext.ecerule.ece.Equality;
import org.xtext.ecerule.ece.FluentWhoseValue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Equality</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.xtext.ecerule.ece.impl.EqualityImpl#getValueOfFluent <em>Value Of Fluent</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EqualityImpl extends AndImpl implements Equality
{
  /**
   * The cached value of the '{@link #getValueOfFluent() <em>Value Of Fluent</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getValueOfFluent()
   * @generated
   * @ordered
   */
  protected FluentWhoseValue valueOfFluent;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EqualityImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return EcePackage.Literals.EQUALITY;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FluentWhoseValue getValueOfFluent()
  {
    return valueOfFluent;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain basicSetValueOfFluent(FluentWhoseValue newValueOfFluent, NotificationChain msgs)
  {
    FluentWhoseValue oldValueOfFluent = valueOfFluent;
    valueOfFluent = newValueOfFluent;
    if (eNotificationRequired())
    {
      ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, EcePackage.EQUALITY__VALUE_OF_FLUENT, oldValueOfFluent, newValueOfFluent);
      if (msgs == null) msgs = notification; else msgs.add(notification);
    }
    return msgs;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setValueOfFluent(FluentWhoseValue newValueOfFluent)
  {
    if (newValueOfFluent != valueOfFluent)
    {
      NotificationChain msgs = null;
      if (valueOfFluent != null)
        msgs = ((InternalEObject)valueOfFluent).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - EcePackage.EQUALITY__VALUE_OF_FLUENT, null, msgs);
      if (newValueOfFluent != null)
        msgs = ((InternalEObject)newValueOfFluent).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - EcePackage.EQUALITY__VALUE_OF_FLUENT, null, msgs);
      msgs = basicSetValueOfFluent(newValueOfFluent, msgs);
      if (msgs != null) msgs.dispatch();
    }
    else if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, EcePackage.EQUALITY__VALUE_OF_FLUENT, newValueOfFluent, newValueOfFluent));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case EcePackage.EQUALITY__VALUE_OF_FLUENT:
        return basicSetValueOfFluent(null, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case EcePackage.EQUALITY__VALUE_OF_FLUENT:
        return getValueOfFluent();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case EcePackage.EQUALITY__VALUE_OF_FLUENT:
        setValueOfFluent((FluentWhoseValue)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case EcePackage.EQUALITY__VALUE_OF_FLUENT:
        setValueOfFluent((FluentWhoseValue)null);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case EcePackage.EQUALITY__VALUE_OF_FLUENT:
        return valueOfFluent != null;
    }
    return super.eIsSet(featureID);
  }

} //EqualityImpl
