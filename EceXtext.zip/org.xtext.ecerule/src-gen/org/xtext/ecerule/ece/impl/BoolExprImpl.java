/**
 */
package org.xtext.ecerule.ece.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.xtext.ecerule.ece.BoolExpr;
import org.xtext.ecerule.ece.EcePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Bool Expr</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class BoolExprImpl extends MinimalEObjectImpl.Container implements BoolExpr
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected BoolExprImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return EcePackage.Literals.BOOL_EXPR;
  }

} //BoolExprImpl
