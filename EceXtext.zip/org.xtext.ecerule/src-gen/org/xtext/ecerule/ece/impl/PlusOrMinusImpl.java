/**
 */
package org.xtext.ecerule.ece.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.ecerule.ece.EcePackage;
import org.xtext.ecerule.ece.PlusOrMinus;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Plus Or Minus</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class PlusOrMinusImpl extends ComparisonImpl implements PlusOrMinus
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected PlusOrMinusImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return EcePackage.Literals.PLUS_OR_MINUS;
  }

} //PlusOrMinusImpl
