/**
 */
package org.xtext.ecerule.ece;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>String Expr</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.ecerule.ece.StringExpr#getValueDirect <em>Value Direct</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.ecerule.ece.EcePackage#getStringExpr()
 * @model
 * @generated
 */
public interface StringExpr extends Equality
{
  /**
   * Returns the value of the '<em><b>Value Direct</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value Direct</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value Direct</em>' attribute.
   * @see #setValueDirect(String)
   * @see org.xtext.ecerule.ece.EcePackage#getStringExpr_ValueDirect()
   * @model
   * @generated
   */
  String getValueDirect();

  /**
   * Sets the value of the '{@link org.xtext.ecerule.ece.StringExpr#getValueDirect <em>Value Direct</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value Direct</em>' attribute.
   * @see #getValueDirect()
   * @generated
   */
  void setValueDirect(String value);

} // StringExpr
