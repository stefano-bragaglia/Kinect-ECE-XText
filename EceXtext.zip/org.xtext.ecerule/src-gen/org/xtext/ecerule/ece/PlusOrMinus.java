/**
 */
package org.xtext.ecerule.ece;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Plus Or Minus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.ecerule.ece.EcePackage#getPlusOrMinus()
 * @model
 * @generated
 */
public interface PlusOrMinus extends Comparison
{
} // PlusOrMinus
