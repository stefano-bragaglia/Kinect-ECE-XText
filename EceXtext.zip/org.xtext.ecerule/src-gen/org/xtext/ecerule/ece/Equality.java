/**
 */
package org.xtext.ecerule.ece;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equality</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.xtext.ecerule.ece.Equality#getValueOfFluent <em>Value Of Fluent</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.xtext.ecerule.ece.EcePackage#getEquality()
 * @model
 * @generated
 */
public interface Equality extends And
{
  /**
   * Returns the value of the '<em><b>Value Of Fluent</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Value Of Fluent</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Value Of Fluent</em>' containment reference.
   * @see #setValueOfFluent(FluentWhoseValue)
   * @see org.xtext.ecerule.ece.EcePackage#getEquality_ValueOfFluent()
   * @model containment="true"
   * @generated
   */
  FluentWhoseValue getValueOfFluent();

  /**
   * Sets the value of the '{@link org.xtext.ecerule.ece.Equality#getValueOfFluent <em>Value Of Fluent</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Value Of Fluent</em>' containment reference.
   * @see #getValueOfFluent()
   * @generated
   */
  void setValueOfFluent(FluentWhoseValue value);

} // Equality
