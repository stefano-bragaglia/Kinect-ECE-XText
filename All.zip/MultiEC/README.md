Freckles
========

Drools session for a Model of Multivalued Event Calculus framework

Requires 'gradle' and 'drools'...
