/**
 * 
 */
package rec.config;

/**
 * @author stefano
 * 
 */
public enum Mode {
	LITE, FULL
}
