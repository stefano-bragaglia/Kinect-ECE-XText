/**
 * 
 */
package rec.config;

/**
 * @author stefano
 * 
 */
public enum Clock {
	PSEUDO, REALTIME
}
