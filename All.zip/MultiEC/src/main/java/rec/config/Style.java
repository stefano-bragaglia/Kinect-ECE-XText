/**
 * 
 */
package rec.config;

/**
 * @author stefano
 * 
 */
public enum Style {
	CLOUD, STREAM
}
