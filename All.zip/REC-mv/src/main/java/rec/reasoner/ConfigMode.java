/**
 * 
 */
package rec.reasoner;

/**
 * @author stefano
 * 
 */
public enum ConfigMode implements IConfigOption {
	LITE, FULL;
}
