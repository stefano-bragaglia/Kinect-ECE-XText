/**
 * 
 */
package rec.reasoner;

/**
 * @author stefano
 * 
 */
public enum ConfigClock implements IConfigOption {
	PSEUDO_TIME, REAL_TIME;
}
