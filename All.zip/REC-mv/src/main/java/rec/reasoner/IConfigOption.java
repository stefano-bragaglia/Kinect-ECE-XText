/**
 * 
 */
package rec.reasoner;

/**
 * @author stefano
 *
 */
public interface IConfigOption {

}
