/**
 */
package org.xtext.ecerule.ece;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>At Expr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.ecerule.ece.EcePackage#getAtExpr()
 * @model
 * @generated
 */
public interface AtExpr extends EObject
{
} // AtExpr
