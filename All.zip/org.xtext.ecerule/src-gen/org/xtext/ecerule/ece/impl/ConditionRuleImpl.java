/**
 */
package org.xtext.ecerule.ece.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.xtext.ecerule.ece.ConditionRule;
import org.xtext.ecerule.ece.EcePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Condition Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ConditionRuleImpl extends MinimalEObjectImpl.Container implements ConditionRule
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ConditionRuleImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return EcePackage.Literals.CONDITION_RULE;
  }

} //ConditionRuleImpl
