/**
 */
package org.xtext.ecerule.ece.impl;

import org.eclipse.emf.ecore.EClass;

import org.xtext.ecerule.ece.EcePackage;
import org.xtext.ecerule.ece.EventFeature;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Feature</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class EventFeatureImpl extends ReferenceTypeImpl implements EventFeature
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EventFeatureImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return EcePackage.Literals.EVENT_FEATURE;
  }

} //EventFeatureImpl
