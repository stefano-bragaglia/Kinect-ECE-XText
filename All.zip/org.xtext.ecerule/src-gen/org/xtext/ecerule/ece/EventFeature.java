/**
 */
package org.xtext.ecerule.ece;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.ecerule.ece.EcePackage#getEventFeature()
 * @model
 * @generated
 */
public interface EventFeature extends ReferenceType
{
} // EventFeature
