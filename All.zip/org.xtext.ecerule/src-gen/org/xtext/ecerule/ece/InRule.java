/**
 */
package org.xtext.ecerule.ece;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>In Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.xtext.ecerule.ece.EcePackage#getInRule()
 * @model
 * @generated
 */
public interface InRule extends EObject
{
} // InRule
