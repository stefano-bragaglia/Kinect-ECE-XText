package org.xtext.ecerule.model;

public interface EventInterface {

	public void setEventName(String eventName);
	
	public String getEventName();

	public void addEventFeature(String eventFeatureName);

}
