package org.xtext.ecerule.model;

public interface ExpressionInterface {

	/**
	 * @param parameters
	 * @return
	 */
	public boolean validate(String[] parameters);
	public double validate();
	
	

}