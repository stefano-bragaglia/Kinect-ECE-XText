package org.ece.test;

public class Prova {

	public static void main(String[] args) {
		TestGenExpDrl.mainRun();

	}

}
