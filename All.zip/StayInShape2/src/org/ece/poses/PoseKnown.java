package org.ece.poses;

import human_model.HumanModel;

public interface PoseKnown {

	public HumanModel getHm();
	
	public String getHumanPoseName();
}
