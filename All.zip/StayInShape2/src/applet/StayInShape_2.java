package applet;


public class StayInShape_2 {
	
	public static void main(String[] args){
		new Background(args.length > 0 && args[0].equals("-fake"));
		
//		bg.setBackGroundPanel();

	}
}
