package org.xtext.ecerule.tests;

import javax.inject.Inject;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.junit4.InjectWith;
import org.eclipse.xtext.junit4.XtextRunner;
import org.eclipse.xtext.junit4.util.ParseHelper;
import org.eclipse.xtext.junit4.validation.ValidationTestHelper;
import org.eclipse.xtext.xbase.compiler.CompilationTestHelper;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Extension;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.xtext.ecerule.EceInjectorProvider;
import org.xtext.ecerule.ece.EceModel;

@RunWith(XtextRunner.class)
@InjectWith(EceInjectorProvider.class)
@SuppressWarnings("all")
public class MyTest {
  @Inject
  @Extension
  private ParseHelper<EceModel> _parseHelper;
  
  @Inject
  @Extension
  private ValidationTestHelper _validationTestHelper;
  
  @Inject
  @Extension
  private CompilationTestHelper _compilationTestHelper;
  
  @Test
  public void testErrorParsing() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("on Start set LeftArmLowered to 1;");
      _builder.newLine();
      _builder.append("on LeftArmStretched expect LeftArmLowered==1 after 10; ");
      _builder.newLine();
      EceModel _parse = this._parseHelper.parse(_builder);
      this._validationTestHelper.assertNoErrors(_parse);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Test
  public void testGeneratedCode() {
    try {
      StringConcatenation _builder = new StringConcatenation();
      _builder.append("on Start set LeftArmLowered to 1;");
      _builder.newLine();
      _builder.append("on LeftArmStretched expect LeftArmLowered==1 after 10; ");
      _builder.newLine();
      StringConcatenation _builder_1 = new StringConcatenation();
      _builder_1.append("package org.ece.include;");
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.append("import org.xtext.ecerule.model.*;");
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.append("import org.xtext.ecerule.model.conditions.*;");
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.append("import org.xtext.ecerule.model.conditions.compounds.*;");
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.append("import org.xtext.ecerule.model.conditions.relations.*;");
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.append("import org.xtext.ecerule.model.expressions.*;");
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.append("import org.xtext.ecerule.model.expressions.operations.*;");
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.append("public class MainEce {");
      _builder_1.newLine();
      _builder_1.append("\t\t");
      _builder_1.newLine();
      _builder_1.append("\t\t");
      _builder_1.append("public static Model getModel() {\t");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("Statement statement;");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("Event event;");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("String eventName;");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("ExpressionInterface exprContainer;");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("ConditionInterface condContainer;");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("//EcContext ecContext;");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("ExpContext expContext;");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("Time time;");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("Model model = new Model();");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.newLine();
      _builder_1.append("\t\t");
      _builder_1.append("statement = new Statement();");
      _builder_1.newLine();
      _builder_1.append("event = new Event();");
      _builder_1.newLine();
      _builder_1.append("eventName = \"Start\";");
      _builder_1.newLine();
      _builder_1.append("event.setEventName(eventName);");
      _builder_1.newLine();
      _builder_1.append("statement.setEvent(event);");
      _builder_1.newLine();
      _builder_1.append(" \t\t\t\t\t\t\t\t");
      _builder_1.append("//ecContext = new EcContext();");
      _builder_1.newLine();
      _builder_1.append("//statement.addEcContext(ecContext);");
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.append("\t\t\t\t\t\t\t\t\t\t\t\t\t");
      _builder_1.append("model.add(\"StmStart\", statement);");
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.append("\t\t");
      _builder_1.append("statement = new Statement();");
      _builder_1.newLine();
      _builder_1.append("event = new Event();");
      _builder_1.newLine();
      _builder_1.append("eventName = \"BraccioAlzato\";");
      _builder_1.newLine();
      _builder_1.append("event.setEventName(eventName);");
      _builder_1.newLine();
      _builder_1.append("statement.setEvent(event);");
      _builder_1.newLine();
      _builder_1.append(" \t\t\t\t\t\t\t\t");
      _builder_1.newLine();
      _builder_1.append("expContext = new ExpContext();");
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.append("//default compileCond");
      _builder_1.newLine();
      _builder_1.append("//TYPE OF condExpr IS---> Reference");
      _builder_1.newLine();
      _builder_1.append("time = new Time();");
      _builder_1.newLine();
      _builder_1.append("time.setAllenOp(\"after\");");
      _builder_1.newLine();
      _builder_1.append("\t\t");
      _builder_1.append("time.setTimeValue(10);");
      _builder_1.newLine();
      _builder_1.append("expContext.setTime(time);");
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.append("statement.addExpContext(expContext);");
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.append("\t\t\t\t\t\t\t\t\t\t\t\t\t");
      _builder_1.append("model.add(\"StmBraccioAlzato\", statement);");
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.newLine();
      _builder_1.append("\t\t\t");
      _builder_1.append("return model;");
      _builder_1.newLine();
      _builder_1.append("\t\t");
      _builder_1.append("}\t");
      _builder_1.newLine();
      _builder_1.append("\t");
      _builder_1.append("}");
      _builder_1.newLine();
      this._compilationTestHelper.assertCompilesTo(_builder, _builder_1);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
